# Cool Pi AI Android starter

Native Kotlin starter app for the Cool Pi AI personal assistant.

## Included
- Remote OpenAI-compatible Chat Completions API support.
- Editable API base URL, model name, and API key settings.
- User-selected text-file import; content is sent only when you tap Send.
- Voice input through Android's speech recognition intent (provider may use the internet).
- Text-to-speech using Android's installed TTS engine.
- Allowlisted launcher for Chrome, Telegram, and Termux when installed.
- Accessibility service placeholder. It does not read screens or automate actions yet.
- GitHub Actions workflow that builds a debug APK and uploads it as an artifact.

## Build
GitHub Actions -> Build Cool Pi AI Android APK -> Run workflow. Download `cool-pi-ai-debug-apk` from the completed run's Artifacts section.

## API settings
Use your provider's OpenAI-compatible base URL, model identifier, and API key. Default base URL is `https://api.deepseek.com/v1`; verify the exact endpoint/model available on your account. The app stores the key in private app preferences, but a key stored on-device is not protected from someone with control of the device. Do not publish a personal API key or embed one in source code.

## Limitations / next steps
- This is a first build scaffold, not a fully autonomous assistant.
- Chat uses the remote provider; no local model is bundled.
- Selected text files only; PDF, Office documents, and broad folder indexing are not implemented.
- The speech recognizer's offline capability depends on Android's installed provider.
- App launching is allowlisted. The accessibility service intentionally performs no automation yet. Add narrow actions and confirmation UI before enabling automation.
- For safe production use, move provider API calls behind an authenticated backend instead of keeping a provider key on the device.
