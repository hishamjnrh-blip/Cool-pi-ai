package ai.coolpi.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("coolpi_settings", MODE_PRIVATE) }
    private lateinit var log: TextView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private var attachedText = ""
    private var tts: TextToSpeech? = null

    companion object { private const val PICK_TEXT = 10; private const val SPEECH = 11 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        addLine("Cool Pi AI", "Ready. Set your API endpoint, model, and key in Settings to begin.")
        addLine("Privacy", "Messages you send go to the configured AI provider. Files are only read after you select them and are sent only when you send the prompt.")
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 20, 20, 14); setBackgroundColor(0xFF10151F.toInt()) }
        page.addView(TextView(this).apply { text = "Cool Pi AI"; textSize = 28f; setTextColor(0xFFF4F7FB.toInt()) })
        status = TextView(this).apply { text = "AI provider not configured"; textSize = 13f; setTextColor(0xFF9FB1C8.toInt()); setPadding(0, 8, 0, 12) }
        page.addView(status)
        log = TextView(this).apply { textSize = 15f; setTextColor(0xFFE5EAF2.toInt()); setPadding(0, 8, 0, 8) }
        page.addView(ScrollView(this).apply { addView(log) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        input = EditText(this).apply { hint = "Message Cool Pi AI…"; setTextColor(-1); setHintTextColor(0xFF9FB1C8.toInt()); setBackgroundColor(0xFF202A39.toInt()); minLines = 2; gravity = Gravity.TOP; setPadding(12, 10, 12, 10) }
        page.addView(input)
        page.addView(btn("Send message") { sendMessage() })
        page.addView(btn("Settings: API endpoint, model, key") { showSettings() })
        page.addView(btn("Choose text file") { pickFile() })
        page.addView(btn("Voice input") { voiceInput() })
        page.addView(btn("Speak last response") { speakLast() })
        page.addView(btn("Open an app") { showApps() })
        page.addView(btn("Automation settings (advanced; not active yet)") { startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        setContentView(page)
        refreshStatus()
    }

    private fun btn(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }
    private fun addLine(who: String, message: String) { runOnUiThread { log.append("\n\n$who: $message") } }
    private fun refreshStatus() { status.text = if (prefs.getString("api_key", "").orEmpty().isNotBlank()) "Configured · ${prefs.getString("model", "model name")}" else "AI provider not configured" }

    private fun showSettings() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        fun field(hintText: String, key: String, default: String = ""): EditText = EditText(this).apply {
            hint = hintText; setSingleLine(true); setText(prefs.getString(key, default))
            panel.addView(this)
        }
        val endpoint = field("API base URL, e.g. https://api.example.com/v1", "endpoint", "https://api.deepseek.com/v1")
        val model = field("Model name supplied by your provider", "model", "deepseek-chat")
        val key = field("API key (stored on this device)", "api_key").apply { inputType = 0x00000081 }
        AlertDialog.Builder(this).setTitle("AI provider settings")
            .setMessage("Use an OpenAI-compatible Chat Completions API. The key is stored in app preferences, not securely hidden from a device owner or APK reverse engineering.")
            .setView(panel).setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("endpoint", endpoint.text.toString().trim().trimEnd('/'))
                    .putString("model", model.text.toString().trim()).putString("api_key", key.text.toString().trim()).apply()
                refreshStatus(); Toast.makeText(this, "Settings saved on this device", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun sendMessage() {
        val userText = input.text.toString().trim()
        if (userText.isEmpty()) return
        val key = prefs.getString("api_key", "").orEmpty()
        val endpoint = prefs.getString("endpoint", "https://api.deepseek.com/v1").orEmpty().trimEnd('/')
        val model = prefs.getString("model", "deepseek-chat").orEmpty()
        if (key.isBlank()) { Toast.makeText(this, "Open Settings and enter your API key first", Toast.LENGTH_LONG).show(); return }
        val prompt = if (attachedText.isBlank()) userText else "$userText\n\nSelected file content:\n${attachedText.take(16000)}"
        attachedText = ""
        input.setText("")
        addLine("You", userText)
        status.text = "Contacting AI provider…"
        worker.execute {
            var connection: HttpURLConnection? = null
            try {
                val urlText = if (endpoint.endsWith("/chat/completions")) endpoint else "$endpoint/chat/completions"
                connection = (URL(urlText).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $key")
                }
                val body = JSONObject().put("model", model).put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", "You are Cool Pi AI, a helpful personal assistant. Reply in the user's language, including Hausa, English, and Nigerian Pidgin when appropriate. You cannot directly control phone apps; only claim actions confirmed by the Android app."))
                    .put(JSONObject().put("role", "user").put("content", prompt)))
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
                if (code !in 200..299) throw IllegalStateException("HTTP $code: ${response.take(700)}")
                val answer = JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "No response text")
                prefs.edit().putString("last_answer", answer).apply()
                addLine("Cool Pi AI", answer)
                runOnUiThread { status.text = "Connected · $model" }
            } catch (e: Exception) {
                addLine("Error", e.message ?: "Request failed. Check network and API settings.")
                runOnUiThread { status.text = "Request failed" }
            } finally { connection?.disconnect() }
        }
    }

    private fun pickFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/*" }
        startActivityForResult(intent, PICK_TEXT)
    }

    @Deprecated("Simple starter implementation; migrate to Activity Result APIs in a later pass.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == PICK_TEXT) {
            val uri: Uri = data.data ?: return
            worker.execute {
                try {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                    attachedText = text.take(16000)
                    runOnUiThread { input.setText("Summarize the selected file. (File content will be sent with this prompt.)"); Toast.makeText(this, "File selected; review the prompt and tap Send", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) { addLine("File error", e.message ?: "Unable to read selected text file") }
            }
        } else if (requestCode == SPEECH) {
            val spoken = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) input.setText(spoken)
        }
    }

    private fun voiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Cool Pi AI")
        }
        try { startActivityForResult(intent, SPEECH) } catch (_: Exception) { Toast.makeText(this, "No speech recognizer available", Toast.LENGTH_LONG).show() }
    }

    private fun speakLast() {
        val text = prefs.getString("last_answer", "").orEmpty()
        if (text.isBlank()) Toast.makeText(this, "No answer to speak yet", Toast.LENGTH_SHORT).show()
        else tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "coolpi-last-answer")
    }
    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }

    private fun showApps() {
        val apps = listOf("Chrome" to "com.android.chrome", "Telegram" to "org.telegram.messenger", "Termux" to "com.termux")
            .filter { packageManager.getLaunchIntentForPackage(it.second) != null }
        if (apps.isEmpty()) { Toast.makeText(this, "No supported apps found", Toast.LENGTH_LONG).show(); return }
        AlertDialog.Builder(this).setTitle("Open app").setItems(apps.map { it.first }.toTypedArray()) { _, i ->
            packageManager.getLaunchIntentForPackage(apps[i].second)?.let { startActivity(it) }
        }.setNegativeButton("Cancel", null).show()
    }

    override fun onDestroy() { tts?.shutdown(); worker.shutdownNow(); super.onDestroy() }
}
